
##setGeneric(
##  "get.bd.chrtcs",
##  function(object, ...) {
##    standardGeneric("get.bd.chrtcs")
##  }
##)
##setGeneric(
##  "set.bd.chrtcs<-",
##  function(object, value, ...) {
##    standardGeneric("set.bd.chrtcs<-")
##  }
##)
##setGeneric(
##  "view.WIG",
##  function(object, chr="chr1", start=1985001, end=2000000, ...) {
##    standardGeneric("view.WIG")
##  }
##)
##setGeneric(
##  "set.ChIP<-",
##  function(object, value, ...) {
##    standardGeneric("set.ChIP<-")
##  }
##)
##setGeneric(
##  "set.Input<-",
##  function(object, value, ...) {
##    standardGeneric("set.Input<-")
##  }
##)
